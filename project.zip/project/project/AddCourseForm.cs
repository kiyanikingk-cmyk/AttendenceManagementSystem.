using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace project
{
    /// <summary>
    /// Form for Adding, Viewing, and Deleting Courses
    /// </summary>
    public partial class AddCourseForm : Form
    {
        public AddCourseForm()
        {
            InitializeComponent();
            LoadCourses();
        }

        // Load courses into DataGridView
        private void LoadCourses()
        {
            try
            {
                string query = "SELECT CourseId, CourseName FROM Courses ORDER BY CourseId";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvCourses.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Add Course Button Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(txtCourseId.Text))
            {
                MessageBox.Show("Please enter Course ID", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCourseName.Text))
            {
                MessageBox.Show("Please enter Course Name", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Validate Course ID is numeric
                int courseId;
                if (!int.TryParse(txtCourseId.Text.Trim(), out courseId))
                {
                    MessageBox.Show("Course ID must be a valid number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Check if Course ID already exists
                string checkQuery = "SELECT COUNT(*) FROM Courses WHERE CourseId = @CourseId";
                SqlParameter[] checkParams = {
                    new SqlParameter("@CourseId", courseId)
                };
                DataTable checkDt = DatabaseHelper.ExecuteQuery(checkQuery, checkParams);
                
                if (checkDt.Rows.Count > 0 && Convert.ToInt32(checkDt.Rows[0][0]) > 0)
                {
                    MessageBox.Show("Course ID already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Insert course
                string query = "INSERT INTO Courses (CourseId, CourseName) VALUES (@CourseId, @CourseName)";
                SqlParameter[] parameters = {
                    new SqlParameter("@CourseId", courseId),
                    new SqlParameter("@CourseName", txtCourseName.Text.Trim())
                };

                int result = DatabaseHelper.ExecuteNonQuery(query, parameters);
                
                if (result > 0)
                {
                    MessageBox.Show("Course added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields();
                    LoadCourses();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding course: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Delete Course Button Click
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvCourses.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a course to delete", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this course? This will also delete all related students and attendance records.", 
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int courseId = Convert.ToInt32(dgvCourses.SelectedRows[0].Cells["CourseId"].Value);
                    
                    // First delete attendance records for this course
                    string deleteAttendanceQuery = "DELETE FROM Attendance WHERE CourseId = @CourseId";
                    SqlParameter[] attendanceParams = {
                        new SqlParameter("@CourseId", courseId)
                    };
                    DatabaseHelper.ExecuteNonQuery(deleteAttendanceQuery, attendanceParams);

                    // Delete students for this course
                    string deleteStudentsQuery = "DELETE FROM Students WHERE CourseId = @CourseId";
                    SqlParameter[] studentsParams = {
                        new SqlParameter("@CourseId", courseId)
                    };
                    DatabaseHelper.ExecuteNonQuery(deleteStudentsQuery, studentsParams);

                    // Then delete the course
                    string deleteCourseQuery = "DELETE FROM Courses WHERE CourseId = @CourseId";
                    SqlParameter[] courseParams = {
                        new SqlParameter("@CourseId", courseId)
                    };

                    int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteCourseQuery, courseParams);
                    
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Course deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadCourses();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting course: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Clear input fields
        private void ClearFields()
        {
            txtCourseId.Clear();
            txtCourseName.Clear();
        }

        // Close button
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

