using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace project
{
    /// <summary>
    /// Form for Marking Attendance
    /// </summary>
    public partial class AttendanceForm : Form
    {
        public AttendanceForm()
        {
            InitializeComponent();
            LoadCourses();
            dtpDate.Value = DateTime.Now;
        }

        // Load courses into ComboBox
        private void LoadCourses()
        {
            try
            {
                cmbCourse.DataSource = null;
                cmbCourse.Items.Clear();
                
                string query = "SELECT CourseId, CourseName FROM Courses ORDER BY CourseName";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                
                if (dt != null && dt.Rows.Count > 0)
                {
                    cmbCourse.DataSource = dt;
                    cmbCourse.DisplayMember = "CourseName";
                    cmbCourse.ValueMember = "CourseId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load students based on selected course
        private void LoadStudents()
        {
            try
            {
                cmbStudent.DataSource = null;
                cmbStudent.Items.Clear();
                
                if (cmbCourse.SelectedValue == null || cmbCourse.Items.Count == 0)
                {
                    return;
                }

                // Handle DataRowView conversion
                int courseId;
                if (cmbCourse.SelectedValue is DataRowView)
                {
                    DataRowView row = (DataRowView)cmbCourse.SelectedValue;
                    courseId = Convert.ToInt32(row["CourseId"]);
                }
                else
                {
                    courseId = Convert.ToInt32(cmbCourse.SelectedValue);
                }

                string query = "SELECT StudentId, StudentName + ' (Roll: ' + RollNo + ')' AS DisplayName FROM Students WHERE CourseId = @CourseId ORDER BY StudentName";
                SqlParameter[] parameters = {
                    new SqlParameter("@CourseId", courseId)
                };
                
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                
                if (dt != null && dt.Rows.Count > 0)
                {
                    cmbStudent.DataSource = dt;
                    cmbStudent.DisplayMember = "DisplayName";
                    cmbStudent.ValueMember = "StudentId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading students: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Course selection changed
        private void cmbCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadStudents();
        }

        // Save Attendance Button Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Validate input
            if (cmbCourse.SelectedValue == null)
            {
                MessageBox.Show("Please select a Course", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbStudent.SelectedValue == null)
            {
                MessageBox.Show("Please select a Student", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!rbPresent.Checked && !rbAbsent.Checked)
            {
                MessageBox.Show("Please select attendance status (Present/Absent)", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string status = rbPresent.Checked ? "Present" : "Absent";
                
                // Handle DataRowView conversion for Student
                int studentId;
                if (cmbStudent.SelectedValue is DataRowView)
                {
                    DataRowView row = (DataRowView)cmbStudent.SelectedValue;
                    studentId = Convert.ToInt32(row["StudentId"]);
                }
                else
                {
                    studentId = Convert.ToInt32(cmbStudent.SelectedValue);
                }
                
                // Handle DataRowView conversion for Course
                int courseId;
                if (cmbCourse.SelectedValue is DataRowView)
                {
                    DataRowView row = (DataRowView)cmbCourse.SelectedValue;
                    courseId = Convert.ToInt32(row["CourseId"]);
                }
                else
                {
                    courseId = Convert.ToInt32(cmbCourse.SelectedValue);
                }
                
                DateTime selectedDate = dtpDate.Value.Date;

                // Check if attendance already exists for this student, course, and date
                string checkQuery = "SELECT COUNT(*) FROM Attendance WHERE StudentId = @StudentId AND CourseId = @CourseId AND Date = @Date";
                SqlParameter[] checkParams = {
                    new SqlParameter("@StudentId", studentId),
                    new SqlParameter("@CourseId", courseId),
                    new SqlParameter("@Date", selectedDate)
                };
                
                DataTable checkDt = DatabaseHelper.ExecuteQuery(checkQuery, checkParams);
                
                if (checkDt.Rows.Count > 0 && Convert.ToInt32(checkDt.Rows[0][0]) > 0)
                {
                    // Update existing attendance
                    string updateQuery = "UPDATE Attendance SET Status = @Status WHERE StudentId = @StudentId AND CourseId = @CourseId AND Date = @Date";
                    SqlParameter[] updateParams = {
                        new SqlParameter("@Status", status),
                        new SqlParameter("@StudentId", studentId),
                        new SqlParameter("@CourseId", courseId),
                        new SqlParameter("@Date", selectedDate)
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);
                    
                    if (result > 0)
                    {
                        MessageBox.Show("Attendance updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearFields();
                    }
                }
                else
                {
                    // Insert new attendance
                    string insertQuery = "INSERT INTO Attendance (StudentId, CourseId, Date, Status) VALUES (@StudentId, @CourseId, @Date, @Status)";
                    SqlParameter[] insertParams = {
                        new SqlParameter("@StudentId", studentId),
                        new SqlParameter("@CourseId", courseId),
                        new SqlParameter("@Date", selectedDate),
                        new SqlParameter("@Status", status)
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(insertQuery, insertParams);
                    
                    if (result > 0)
                    {
                        MessageBox.Show("Attendance saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearFields();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving attendance: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Clear input fields
        private void ClearFields()
        {
            if (cmbStudent.Items.Count > 0)
                cmbStudent.SelectedIndex = -1;
            rbPresent.Checked = false;
            rbAbsent.Checked = false;
            dtpDate.Value = DateTime.Now;
        }

        // Close button
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

