-- =============================================
-- Attendance Management System Database Structure
-- Database Name: AttendanceDB
-- =============================================

-- Create Database (Uncomment if needed)
-- CREATE DATABASE AttendanceDB;
-- GO

-- USE AttendanceDB;
-- GO

-- =============================================
-- Table: Courses
-- =============================================
CREATE TABLE Courses (
    CourseId INT PRIMARY KEY,
    CourseName VARCHAR(100) NOT NULL
);
GO

-- =============================================
-- Table: Students
-- =============================================
CREATE TABLE Students (
    StudentId INT PRIMARY KEY,
    StudentName VARCHAR(100) NOT NULL,
    RollNo VARCHAR(50) NOT NULL,
    CourseId INT NOT NULL,
    FOREIGN KEY (CourseId) REFERENCES Courses(CourseId) ON DELETE CASCADE
);
GO

-- =============================================
-- Table: Attendance
-- =============================================
CREATE TABLE Attendance (
    AttendanceId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT NOT NULL,
    CourseId INT NOT NULL,
    Date DATE NOT NULL,
    Status VARCHAR(10) NOT NULL CHECK (Status IN ('Present', 'Absent')),
    FOREIGN KEY (StudentId) REFERENCES Students(StudentId) ON DELETE CASCADE,
    FOREIGN KEY (CourseId) REFERENCES Courses(CourseId) ON DELETE NO ACTION,
    UNIQUE (StudentId, CourseId, Date) -- Prevent duplicate attendance for same student, course, and date
);
GO

-- =============================================
-- Sample Data (Optional - for testing)
-- =============================================

-- Insert Sample Courses
-- INSERT INTO Courses (CourseId, CourseName) VALUES (1, 'Mathematics');
-- INSERT INTO Courses (CourseId, CourseName) VALUES (2, 'Computer Science');
-- INSERT INTO Courses (CourseId, CourseName) VALUES (3, 'Physics');
-- GO

-- Insert Sample Students
-- INSERT INTO Students (StudentId, StudentName, RollNo, CourseId) VALUES (1, 'John Doe', 'R001', 1);
-- INSERT INTO Students (StudentId, StudentName, RollNo, CourseId) VALUES (2, 'Jane Smith', 'R002', 1);
-- INSERT INTO Students (StudentId, StudentName, RollNo, CourseId) VALUES (3, 'Bob Johnson', 'R003', 2);
-- GO

-- =============================================
-- End of Database Structure
-- =============================================

