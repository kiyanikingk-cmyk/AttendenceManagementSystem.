using System;
using System.Windows.Forms;

namespace project
{
    /// <summary>
    /// Main Form - Entry point of the application
    /// </summary>
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Test database connection on form load
            DatabaseHelper.TestConnection();
        }

        // Navigate to Add Student Form
        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            AddStudentForm addStudentForm = new AddStudentForm();
            addStudentForm.ShowDialog();
        }

        // Navigate to Add Course Form
        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            AddCourseForm addCourseForm = new AddCourseForm();
            addCourseForm.ShowDialog();
        }

        // Navigate to Mark Attendance Form
        private void btnMarkAttendance_Click(object sender, EventArgs e)
        {
            AttendanceForm attendanceForm = new AttendanceForm();
            attendanceForm.ShowDialog();
        }

        // Navigate to View Attendance Form
        private void btnViewAttendance_Click(object sender, EventArgs e)
        {
            ViewAttendanceForm viewAttendanceForm = new ViewAttendanceForm();
            viewAttendanceForm.ShowDialog();
        }

        // Navigate to Delete Course Form
        private void btnDeleteCourse_Click(object sender, EventArgs e)
        {
            AddCourseForm deleteCourseForm = new AddCourseForm();
            deleteCourseForm.ShowDialog();
        }
    }
}

