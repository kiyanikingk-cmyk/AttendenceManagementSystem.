using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace project
{
    /// <summary>
    /// Form for Viewing Attendance Records
    /// </summary>
    public partial class ViewAttendanceForm : Form
    {
        public ViewAttendanceForm()
        {
            InitializeComponent();
            LoadCourses();
            LoadAllAttendance();
        }

        // Load courses into ComboBox
        private void LoadCourses()
        {
            try
            {
                cmbFilterCourse.DataSource = null;
                cmbFilterCourse.Items.Clear();
                
                string query = "SELECT CourseId, CourseName FROM Courses ORDER BY CourseName";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                
                if (dt == null)
                {
                    dt = new DataTable();
                    dt.Columns.Add("CourseId", typeof(int));
                    dt.Columns.Add("CourseName", typeof(string));
                }
                
                // Add "All Courses" option
                DataRow row = dt.NewRow();
                row["CourseId"] = 0;
                row["CourseName"] = "All Courses";
                dt.Rows.InsertAt(row, 0);
                
                cmbFilterCourse.DataSource = dt;
                cmbFilterCourse.DisplayMember = "CourseName";
                cmbFilterCourse.ValueMember = "CourseId";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load all attendance records
        private void LoadAllAttendance()
        {
            try
            {
                string query = @"SELECT a.AttendanceId, s.StudentName, s.RollNo, c.CourseName, a.Date, a.Status 
                                FROM Attendance a
                                INNER JOIN Students s ON a.StudentId = s.StudentId
                                INNER JOIN Courses c ON a.CourseId = c.CourseId
                                ORDER BY a.Date DESC, c.CourseName, s.StudentName";
                
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvAttendance.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading attendance: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Filter attendance by course
        private void cmbFilterCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbFilterCourse.SelectedValue == null)
                    return;

                // Handle DataRowView conversion
                int courseId;
                if (cmbFilterCourse.SelectedValue is DataRowView)
                {
                    DataRowView row = (DataRowView)cmbFilterCourse.SelectedValue;
                    courseId = Convert.ToInt32(row["CourseId"]);
                }
                else
                {
                    courseId = Convert.ToInt32(cmbFilterCourse.SelectedValue);
                }
                
                string query;

                if (courseId == 0) // All Courses
                {
                    query = @"SELECT a.AttendanceId, s.StudentName, s.RollNo, c.CourseName, a.Date, a.Status 
                             FROM Attendance a
                             INNER JOIN Students s ON a.StudentId = s.StudentId
                             INNER JOIN Courses c ON a.CourseId = c.CourseId
                             ORDER BY a.Date DESC, c.CourseName, s.StudentName";
                    
                    DataTable dt = DatabaseHelper.ExecuteQuery(query);
                    dgvAttendance.DataSource = dt;
                }
                else
                {
                    query = @"SELECT a.AttendanceId, s.StudentName, s.RollNo, c.CourseName, a.Date, a.Status 
                             FROM Attendance a
                             INNER JOIN Students s ON a.StudentId = s.StudentId
                             INNER JOIN Courses c ON a.CourseId = c.CourseId
                             WHERE a.CourseId = @CourseId
                             ORDER BY a.Date DESC, s.StudentName";
                    
                    SqlParameter[] parameters = {
                        new SqlParameter("@CourseId", courseId)
                    };
                    
                    DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                    dgvAttendance.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error filtering attendance: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Refresh button
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAllAttendance();
            if (cmbFilterCourse.Items.Count > 0)
                cmbFilterCourse.SelectedIndex = 0;
        }

        // Close button
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

