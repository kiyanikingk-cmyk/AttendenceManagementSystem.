using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace project
{
    /// <summary>
    /// Form for Adding, Viewing, and Deleting Students
    /// </summary>
    public partial class AddStudentForm : Form
    {
        public AddStudentForm()
        {
            InitializeComponent();
            LoadCourses();
            LoadStudents();
        }

        // Load courses into ComboBox
        private void LoadCourses()
        {
            try
            {
                cmbCourse.DataSource = null;
                cmbCourse.Items.Clear();
                
                string query = "SELECT CourseId, CourseName FROM Courses ORDER BY CourseName";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                
                if (dt != null && dt.Rows.Count > 0)
                {
                    cmbCourse.DataSource = dt;
                    cmbCourse.DisplayMember = "CourseName";
                    cmbCourse.ValueMember = "CourseId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load students into DataGridView
        private void LoadStudents()
        {
            try
            {
                string query = @"SELECT s.StudentId, s.StudentName, s.RollNo, c.CourseName 
                                 FROM Students s 
                                 INNER JOIN Courses c ON s.CourseId = c.CourseId 
                                 ORDER BY s.StudentId";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvStudents.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading students: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Add Student Button Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(txtStudentId.Text))
            {
                MessageBox.Show("Please enter Student ID", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtStudentName.Text))
            {
                MessageBox.Show("Please enter Student Name", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtRollNo.Text))
            {
                MessageBox.Show("Please enter Roll No", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbCourse.SelectedValue == null || cmbCourse.Items.Count == 0)
            {
                MessageBox.Show("Please select a Course. If no courses are available, please add a course first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Validate Student ID is numeric
                int studentId;
                if (!int.TryParse(txtStudentId.Text.Trim(), out studentId))
                {
                    MessageBox.Show("Student ID must be a valid number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Check if Student ID already exists
                string checkQuery = "SELECT COUNT(*) FROM Students WHERE StudentId = @StudentId";
                SqlParameter[] checkParams = {
                    new SqlParameter("@StudentId", studentId)
                };
                DataTable checkDt = DatabaseHelper.ExecuteQuery(checkQuery, checkParams);
                
                if (checkDt.Rows.Count > 0 && Convert.ToInt32(checkDt.Rows[0][0]) > 0)
                {
                    MessageBox.Show("Student ID already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Insert student
                // Handle DataRowView conversion
                int courseId;
                if (cmbCourse.SelectedValue is DataRowView)
                {
                    DataRowView row = (DataRowView)cmbCourse.SelectedValue;
                    courseId = Convert.ToInt32(row["CourseId"]);
                }
                else
                {
                    courseId = Convert.ToInt32(cmbCourse.SelectedValue);
                }
                
                string query = "INSERT INTO Students (StudentId, StudentName, RollNo, CourseId) VALUES (@StudentId, @StudentName, @RollNo, @CourseId)";
                SqlParameter[] parameters = {
                    new SqlParameter("@StudentId", studentId),
                    new SqlParameter("@StudentName", txtStudentName.Text.Trim()),
                    new SqlParameter("@RollNo", txtRollNo.Text.Trim()),
                    new SqlParameter("@CourseId", courseId)
                };

                int result = DatabaseHelper.ExecuteNonQuery(query, parameters);
                
                if (result > 0)
                {
                    MessageBox.Show("Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields();
                    LoadStudents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding student: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Delete Student Button Click
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student to delete", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this student?", "Confirm Delete", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int studentId = Convert.ToInt32(dgvStudents.SelectedRows[0].Cells["StudentId"].Value);
                    
                    // First delete attendance records for this student
                    string deleteAttendanceQuery = "DELETE FROM Attendance WHERE StudentId = @StudentId";
                    SqlParameter[] attendanceParams = {
                        new SqlParameter("@StudentId", studentId)
                    };
                    DatabaseHelper.ExecuteNonQuery(deleteAttendanceQuery, attendanceParams);

                    // Then delete the student
                    string deleteStudentQuery = "DELETE FROM Students WHERE StudentId = @StudentId";
                    SqlParameter[] studentParams = {
                        new SqlParameter("@StudentId", studentId)
                    };

                    int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteStudentQuery, studentParams);
                    
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadStudents();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting student: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Clear input fields
        private void ClearFields()
        {
            txtStudentId.Clear();
            txtStudentName.Clear();
            txtRollNo.Clear();
            if (cmbCourse.Items.Count > 0)
                cmbCourse.SelectedIndex = 0;
        }

        // Close button
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

